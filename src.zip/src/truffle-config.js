const HDWalletProvider = require('@truffle/hdwallet-provider');
require('dotenv').config();

const { MNEMONIC, ALCHEMY_API_KEY } = process.env;

module.exports = {
  networks: {
    sepolia: {
      provider: () => new HDWalletProvider(
        MNEMONIC, 
        `https://eth-sepolia.alchemyapi.io/v2/${ALCHEMY_API_KEY}`
      ),
      network_id: 11155111, // Sepolia's network ID
      gas: 4465030, // Gas limit (adjust if necessary)
      gasPrice: 1000000000, // Gas price (adjust if necessary)
      from: "0xfb29B111A11C73679E70eaD032C4c383F3f3B029", // Address to deploy from
    },
  },

  compilers: {
    solc: {
      version: "0.8.19", // Make sure the version is compatible with your contracts
    },
  },
};
