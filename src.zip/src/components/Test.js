import React from "react";

const Test = () => {
  return <div>Test</div>;
};

export default Test;
